import re
import string


def printsomething():
    v = input("Enter a number: ")
    y = isinstance(v,int)#check to see if user entered a valid number
    if(y):
         x = 1
         operand = '*'#multiplication operand
         while x<=10:
             print(str(v)+ ' '+ str(operand)+' '+str(x)+' = ' + str(v * x))#print the multiplication table line by line
             x = x+1
    else:
        print("Invalid. Using 1.")#error handle if user doesnt enter a valid integer
        
        v = 1
        x = 1
        operand = '*'
        while x<=10:
            print(str(v)+ ' '+ str(operand)+' '+str(x)+' = ' + str(v * x))
            x = x+1

def DoubleValue(v):#doubling function
    return v + v




    
