import re
import string
import os


def ItemsSoldToday():
    f = open('Purchases.txt','r')
    print("Opening ",f.name)
    print()
    itemList = f.readlines()
    f.close()
    ItemsSold = {}

    for item in itemList:#loop through list to get items
        item = item.strip()#remove new line from end of item
        if item in ItemsSold.keys():#if item already listed, just add 1 to that value
            ItemsSold[item]  = ItemsSold[item] + 1
        else:#if item not listed, list it and set value to 1
            ItemsSold[item] = 1
    for item in ItemsSold:
        itemLJust = item.ljust(15,'.')
        print(itemLJust,ItemsSold[item])

def ItemLookup(searched_item):
    f = open('Purchases.txt','r')
    print("Opening ",f.name)                      
    itemList = f.readlines()
    f.close()
    ItemsSold = {}

    for item in itemList:#loop through list to get items
        item = item.strip()#remove new line from end of item
        if item in ItemsSold.keys():#if item already listed, just add 1 to that value
            ItemsSold[item] = ItemsSold[item] + 1
        else:#if item not listed, list it and set value to 1
            ItemsSold[item] = 1
    return ItemsSold[searched_item]


def HistogramData():  
    g = open('Purchases.txt','r')
    h = open('frequency.dat','w')
    if g.closed:
        print("Error opening file...")
    else:
        print("Purchases.txt successfully opened")
    if h.closed:
        print("Error creating file...")
    else:
        print("Creating frequency.dat file...\n")

    itemList = g.readlines()
    
    ItemsSold = {}

    for item in itemList:#loop through list to get items
        item = item.strip()#remove new line from end of item
        if item in ItemsSold.keys():#if item already listed, just add 1 to that value
            ItemsSold[item] = ItemsSold[item] + 1
        else:#if item not listed, list it and set value to 1
            ItemsSold[item] = 1
    for item in ItemsSold:
        itemLJust = item.ljust(15)
        h.write(itemLJust)
        h.write(str(ItemsSold[item]))
        h.write(" \n")
    h.close()
    g.close()
    if g.closed:
        print("Purchases.txt successfully closed")
    else:
        print("Error closing file...")
    if h.closed:
        print("frequency.dat successfully closed")
    else:
        print("Error closing file...")


    
